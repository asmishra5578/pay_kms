package com.asktech.pgateway.util;

import com.asktech.pgateway.dto.admin.MerchantCreateRequest;

public class ValidationUtils {

	public boolean validateMerchantCreateRequest(MerchantCreateRequest merchantCreateRequest) {
		
		
		
		return false;
	}
}

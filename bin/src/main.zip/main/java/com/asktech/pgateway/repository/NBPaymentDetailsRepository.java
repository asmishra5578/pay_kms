package com.asktech.pgateway.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.asktech.pgateway.model.NBPaymentDetails;

public interface NBPaymentDetailsRepository extends JpaRepository<NBPaymentDetails, String>{

}

package com.asktech.pgateway.model.seam;

import com.asktech.pgateway.model.AbstractTimeStampAndId;

public class SessionDetailsNonSeamless  extends AbstractTimeStampAndId{

}

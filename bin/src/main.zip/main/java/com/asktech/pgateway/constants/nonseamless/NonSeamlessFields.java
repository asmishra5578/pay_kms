package com.asktech.pgateway.constants.nonseamless;

public interface NonSeamlessFields {
	
	String CUSTOMERNAME = "customerName";
	String CUSTOMERPHONE = "customerPhone";
	String CUSTOMEREMAIL = "customerEmail";
	String ORDERAMOUNT = "customerEmail";
	String SIGNATURE = "signature";
	String NOTIFYURL = "notifyURL";
	String ORDERNOTE = "ordernote";
	String ORDERID = "orderID";
	
}

package com.asktech.pgateway.constants.nonseamless;

public interface WalletFields extends Fields{
	String PAYMENT_CODE = "paymentcode";
}

package com.asktech.pgateway.constants;

public interface CardsFields extends Fields{
	String CARD_NUMBER = "card_number";
	String CARD_EXPMONTH = "card_expiryMonth";
	String CARD_EXPYEAR = "card_expiryYear";
	String CARD_CVV = "card_cvv";
	String CARD_HOLDER = "card_holder";	
	
}

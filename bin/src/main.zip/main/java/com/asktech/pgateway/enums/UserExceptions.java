package com.asktech.pgateway.enums;

public enum UserExceptions {
	INVALID_EMAIL;
	UserExceptions(){
		
	}
}

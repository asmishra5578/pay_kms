package com.asktech.pgateway.confg;

public final class CashfreeConfig {
	public static final String appId = "694474f5c857722757164126274496";
	public static final String returnUrl= "http://localhost:8080/notifyurl";
	public static final String notifyUrl = "http://localhost:8080/notifyurl";
	public static final String secretKey = "d21ed9fab44af276472e783cc2c0162f89941fcf";
	public static final String currency = "INR";
}

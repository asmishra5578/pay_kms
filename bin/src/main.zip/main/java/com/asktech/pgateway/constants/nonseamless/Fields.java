package com.asktech.pgateway.constants.nonseamless;

public interface Fields {
	String NAME = "customerName";
	String PHN = "customerPhone";
	String EMAIL = "customerEmail";	
	String ORDERID = "orderId";
	String PAYMENTOPTION = "paymentOption";	
	String SIGNATURE = "signature";
	String CUSTOMERID = "customerid";
	String CURRENCY ="currency";
	String ORDERNOTE = "orderNote";
	String RETURNURL = "returnUrl";
	String NOTIFYURL = "notifyUrl";
	String ORDERAMOUNT = "orderAmount";
	
}

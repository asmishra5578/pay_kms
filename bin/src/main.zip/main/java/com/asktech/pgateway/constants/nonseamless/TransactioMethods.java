package com.asktech.pgateway.constants.nonseamless;

public interface TransactioMethods {
	String CARD = "Card"; 
	String WALLET = "Wallet"; 
	String NETBANKING = "NB";
	String UPI = "Upi";
}
